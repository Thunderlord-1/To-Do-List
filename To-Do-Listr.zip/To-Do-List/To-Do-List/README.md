# To-Do-List Using HTML, CSS & JavaScript

The to-do list I had created has a beautiful UI, the user can add a to-do by filling the input and hit ENTER, after that he can rather check the to-do when it's done, or remove it using the delete button.

The user's to-do list is stored in the local storage, so when he refreshes the page, he can always find the list there.

There is the possibility for the user, to clear the list, by clicking the button clear, at the top right corner of our app.

The to do list app, shows the today's date to the user, for that I used a method called toLocaleDateString.